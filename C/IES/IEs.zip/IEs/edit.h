#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include "administra.h"

void mudaNome(char mudar[]);

void mudaAva(int *a);

void mudaAno(int *a);

void mudaDur(Duracao *dura);

void editMusica(Musica* alvo);

void editar(Playlist* lista);

void editPlay(Playlist* lista);